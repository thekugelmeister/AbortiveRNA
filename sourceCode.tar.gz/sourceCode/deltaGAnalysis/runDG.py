import os, sys

for i in xrange(4,16):
    os.system("python dgcalc.py wob" + str(i))
